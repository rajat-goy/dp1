package net.media.training.live.srp;

public class Address {
    private String Street;
    private String City;
    private String Country;

    Address(String Street, String City, String Country)
    {
        this.City = City;
        this.Street = Street;
        this.Country = Country;
    }

}
