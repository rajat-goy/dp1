package net.media.training.live.srp;

public class LeavesInfo {

    private int TOTAL_LEAVES_ALLOWED = 30;
    private int totalLeaveAllowed;
    private int leaveTaken;

    private int leavesLeft;
    private int[] leavesLeftPreviously;

    LeavesInfo(int leaveTaken,int [] leavesLeftPreviously,int totalLeaveAllowed){
        leavesLeft = totalLeaveAllowed-leaveTaken;
    }
    public int getLeavesLeft(){
        return this.leavesLeft;
    }
    public int getTotalLeavesleftPreviously()
    {
        int years = leavesLeftPreviously.length;
        int totalLeaveLeftPreviously = 0;
        for (int i = 0; i < years; i++) {
            totalLeaveLeftPreviously += leavesLeftPreviously[years-i-1];
        }
        return totalLeaveLeftPreviously;
    }



}
