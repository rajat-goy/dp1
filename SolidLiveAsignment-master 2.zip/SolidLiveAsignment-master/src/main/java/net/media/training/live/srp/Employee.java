package net.media.training.live.srp;


import jdk.vm.ci.meta.Local;

import java.time.LocalDate;

public class Employee {

    private int empId;
    private double monthlySalary;
    private String name;
    public Address address;
    public LeavesInfo leavesInfo;
    private String manager;
    private int yearsInOrg;
    private int thisYear;



    public Employee(int empId, double monthlySalary, String name, Address address,LeavesInfo leavesInfo,int yearsInOrg, String manager) {
        this.empId = empId;
        this.monthlySalary = monthlySalary;
        this.name = name;
        this.address=address;
        this.leavesInfo =leavesInfo;
        this.yearsInOrg = yearsInOrg;
        this.thisYear = LocalDate.now().getYear();
        this.manager = manager;
    }

    public String toHtml()
    {
        HtmlMaker htmlMaker = new HtmlMaker();
        return htmlMaker.getHtml(this);
    }
    public int getEmpId()
    {
        return this.empId;
    }

    public String getName(){
        return name;
    }
    public LeavesInfo getLeavesInfo(){
        return leavesInfo;
    }

    public double getMonthlySalary() {
        return monthlySalary;
    }

    public String getManager() {
        return manager;
    }

    public int getYearsInOrg() {
        return yearsInOrg;
    }


    //other method related to customer
}
