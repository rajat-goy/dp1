package net.media.training.live.isp;

/**
 * Created by IntelliJ IDEA.
 * User: goyalamit
 * Date: Jul 11, 2011
 * Time: 4:28:25 PM
 * To change this template use File | Settings | File Templates.
 */
public interface TimerClient {
void timeOutCallback();
}
