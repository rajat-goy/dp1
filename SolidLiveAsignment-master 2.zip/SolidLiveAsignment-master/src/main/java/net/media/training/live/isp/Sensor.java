package net.media.training.live.isp;

/**
 * Created by IntelliJ IDEA.
 * User: goyalamit
 * Date: Jul 11, 2011
 * Time: 4:22:48 PM
 * To change this template use File | Settings | File Templates.
 */
public class Sensor implements SensorClient{
    public void proximityCallback(){

    }
    public void register(SensorClient sensorClient)
    {
        sensorClient.proximityCallback();
    }
}
